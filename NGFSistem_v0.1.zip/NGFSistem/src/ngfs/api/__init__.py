"""Rutas HTTP de NGFS."""
